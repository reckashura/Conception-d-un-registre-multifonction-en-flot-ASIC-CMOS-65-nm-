library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity AR_register_tb is
end entity;

architecture tb of AR_register_tb is

    -- Component declaration
    component AR_register
        port(
            clk : in std_logic;
            m2, m1, m0 : in std_logic;
            e : in std_logic_vector(3 downto 0);
            serial_in : in std_logic;
            Z : out std_logic_vector(3 downto 0)
        );
    end component;

    -- Signals
    signal clk : std_logic := '0';
    signal m2, m1, m0 : std_logic := '0';
    signal e : std_logic_vector(3 downto 0) := (others => '0');
    signal serial_in : std_logic := '0';
    signal Z : std_logic_vector(3 downto 0);

begin

    -- Instantiate DUT
    uut: AR_register
        port map(
            clk => clk,
            m2 => m2,
            m1 => m1,
            m0 => m0,
            e => e,
            serial_in => serial_in,
            Z => Z
        );

    -- Clock generation (10 ns period)
    clk_process : process
    begin
        while true loop
            clk <= '0';
            wait for 5 ns;
            clk <= '1';
            wait for 5 ns;
        end loop;
    end process;

    -- Stimulus process
    stim_proc: process
    begin
        
        
        -- 1. RESET (01x)
        
        e <= "1111";
        m2 <= '0'; m1 <= '1'; m0 <= '0';
        wait for 10 ns;

        
        -- 2. LOAD parallèle (11x)
        
        e <= "1010";
        m2 <= '1'; m1 <= '1'; m0 <= '0';
        wait for 10 ns;

        
        -- 3. HOLD (000)
        
        m2 <= '0'; m1 <= '0'; m0 <= '0';
        wait for 10 ns;

        
        -- 4. SHIFT LEFT avec serial_in = 0 (001)
       
        serial_in <= '0';
        m2 <= '0'; m1 <= '0'; m0 <= '1';
        wait for 10 ns;

        
        -- 5. SHIFT LEFT avec serial_in = 1
       
        serial_in <= '1';
        wait for 10 ns;

        
        -- 6. DECREMENT -3 
        
        m2 <= '1'; m1 <= '0'; m0 <= '0';
        wait for 10 ns;

        
        -- 7. TEST WRAP-AROUND
        -- Charger petite valeur puis décrémenter
        
        e <= "0001";               -- 1
        m2 <= '1'; m1 <= '1';      -- Load
        wait for 10 ns;

        m2 <= '1'; m1 <= '0';      -- Decrement -3
        wait for 10 ns;


         
        --RESET (01x)
        
        m2 <= '0'; m1 <= '1'; m0 <= '0';
        wait for 10 ns;
        
        
        wait;
        
    end process;

end architecture;
