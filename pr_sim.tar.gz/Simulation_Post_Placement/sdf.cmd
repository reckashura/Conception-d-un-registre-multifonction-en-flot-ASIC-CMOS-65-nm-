COMPILED_SDF_FILE = "./ar_register_pr.sdf.X",
SCOPE = AR_register,
LOG_FILE = "sdf.log",
MTM_CONTROL = "MAXIMUM",
SCALE_FACTORS = "1.0:1.0:1.0",
SCALE_TYPE = "FROM_MTM";
