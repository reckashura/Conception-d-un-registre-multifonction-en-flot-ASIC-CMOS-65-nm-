# Cadence Genus(TM) Synthesis Solution, Version 18.10-p003_1, built Jun  7 2018 23:53:27

# Date: Fri Mar 27 16:38:58 2026
# Host: stc-server (x86_64 w/Linux 3.10.0-1160.66.1.el7.x86_64) (1core*8cpus*15physical cpus*Intel(R) Xeon(R) Gold 6148 CPU @ 2.40GHz 28160KB)
# OS:   CentOS Linux release 7.9.2009 (Core)

quit
