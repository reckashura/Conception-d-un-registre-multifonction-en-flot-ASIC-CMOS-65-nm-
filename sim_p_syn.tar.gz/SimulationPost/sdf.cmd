SDF_FILE = "AR_register_net.sdf",
SCOPE = AR_register_tb/uut;