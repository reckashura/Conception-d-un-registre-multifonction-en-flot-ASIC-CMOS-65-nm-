library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity AR_register is
    port(
        clk : in std_logic;
        m2, m1, m0 : in std_logic;
        e : in std_logic_vector(3 downto 0);
        serial_in : in std_logic;
        Z : out std_logic_vector(3 downto 0)
    );
end entity;

architecture rtl of AR_register is
    signal reg : unsigned(3 downto 0) := (others => '0');
begin

process(clk)
begin
    if rising_edge(clk) then
        
        if (m2='0' and m1='1') then
            reg <= (others => '0');  -- Reset

        elsif (m2='1' and m1='1') then
            reg <= unsigned(e);      -- Load

        elsif (m2='1' and m1='0') then
            reg <= reg - 3;          -- Decrement by 3

        elsif (m2='0' and m1='0' and m0='1') then
            reg <= reg(2 downto 0) & serial_in;  -- Shift left

        else
            reg <= reg;              -- Hold
        end if;

    end if;
end process;

Z <= std_logic_vector(reg);

end architecture;
