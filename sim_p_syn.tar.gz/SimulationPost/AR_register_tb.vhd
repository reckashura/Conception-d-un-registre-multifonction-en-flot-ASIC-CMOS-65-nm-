library ieee;
use ieee.std_logic_1164.all;

entity \AR_register_tb\ is
end \AR_register_tb\;

architecture verilog of \AR_register_tb\ is
	attribute foreign of verilog:architecture is "VERILOG(event) worklib.AR_register_tb:module";
begin
end;

