`timescale 1ns/1ps

module AR_register_tb;

reg clk;
reg m2, m1, m0;
reg [3:0] e;
reg serial_in;
wire [3:0] Z;

// Instanciation du DUT (Design Under Test)
AR_register uut (
    .clk(clk),
    .m2(m2),
    .m1(m1),
    .m0(m0),
    .e(e),
    .serial_in(serial_in),
    .Z(Z)
);

// Génération horloge (10 ns période)
always #5 clk = ~clk;

initial begin
    // Initialisation
    clk = 0;
    m2 = 0; m1 = 0; m0 = 0;
    e = 4'b0000;
    serial_in = 0;

    // 1. RESET (01x)
    e = 4'b1111;
    m2 = 0; m1 = 1; m0 = 0;
    #10;

    // 2. LOAD (11x)
    e = 4'b1010;
    m2 = 1; m1 = 1;
    #10;

    // 3. HOLD (000)
    m2 = 0; m1 = 0; m0 = 0;
    #10;

    // 4. SHIFT LEFT (001) avec serial_in = 0
    serial_in = 0;
    m0 = 1;
    #10;

    // SHIFT LEFT avec serial_in = 1
    serial_in = 1;
    #10;

    // 5. DECREMENT -3 (10x)
    m2 = 1; m1 = 0; m0 = 0;
    #10;

    // 6. TEST WRAP-AROUND
    e = 4'b0001;
    m2 = 1; m1 = 1;
    #10;

    m2 = 1; m1 = 0;
    #10;

    // 7. RESET final
    m2 = 0; m1 = 1;
    #10;

    $stop;
end

endmodule
