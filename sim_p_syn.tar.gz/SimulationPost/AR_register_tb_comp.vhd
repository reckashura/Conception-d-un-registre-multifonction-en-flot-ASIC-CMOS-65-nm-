library ieee;
use ieee.std_logic_1164.all;

package HDLModels is

component \AR_register_tb\
end component;


end HDLModels;
