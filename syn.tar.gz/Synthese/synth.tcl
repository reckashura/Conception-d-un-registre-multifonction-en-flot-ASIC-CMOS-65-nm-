# Afficher GUI
gui_show

# Nom du design
set DESIGN AR_register

# Niveau d'optimisation
set SYN_EFF medium
set MAP_EFF medium

# Verbosité
set_db information_level 9

# Librairies TSMC 65nm
set_db lib_search_path /CMC/kits/tsmc_65nm_libs/tcbn65gplus_200a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tcbn65gplus_140b
set_db library {tcbn65gplusbc.lib}

# LEF (placement futur)
set_db lef_library {/CMC/kits/tsmc_65nm_libs/tcbn65gplus_200a/TSMCHOME/digital/Back_End/lef/tcbn65gplus_200a/lef/tcbn65gplus_6lmT2.lef}

# Lire VHDL
read_hdl -vhdl AR_register.vhdl

# Elaborer
elaborate $DESIGN

# Clock
create_clock -name clk -period 10 [get_ports clk]

# Synthèse
synthesize -to_mapped

# Rapports
report area > area.rpt
report timing > timing.rpt

# Netlist
write_hdl > AR_register_synth.v
