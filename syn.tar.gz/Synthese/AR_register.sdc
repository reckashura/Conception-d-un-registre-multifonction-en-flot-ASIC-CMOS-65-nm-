# ####################################################################
# Fichier de contraintes - AR_register
# ####################################################################

# Unités
set_time_unit -picoseconds
set_load_unit -femtofarads

# Conditions de fonctionnement
set_operating_conditions -max_library PVT_1P1V_0C -min_library PVT_0P9V_125C

# =========================
# Horloge
# =========================

set clk "clk"
create_clock -period 10000 -name $clk [get_ports clk]

# =========================
# Incertitudes horloge
# =========================

set_db [get_clocks $clk] .clock_setup_uncertainty 100
set_db [get_clocks $clk] .clock_hold_uncertainty  30

# =========================
# Délais entrées
# =========================

set_input_delay 500 -clock $clk [remove_from_collection [all_inputs] [get_ports clk]]

# =========================
# Délais sorties
# =========================

set_output_delay 500 -clock $clk [all_outputs]

# =========================
# Charge sortie
# =========================

set_load 10 [all_outputs]
