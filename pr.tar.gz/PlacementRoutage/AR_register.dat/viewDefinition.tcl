if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name worst_case\
   -timing\
    [list ${::IMEX::libVar}/lib/typ/tcbn65gpluswc.lib]
create_rc_corner -name rc\
   -cap_table ${::IMEX::libVar}/mmmc/cln65g+_1p09m+alrdl_rcworst_top2.captable\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -T 25
create_delay_corner -name wrost_corner\
   -library_set worst_case\
   -rc_corner rc
create_constraint_mode -name constraint\
   -sdc_files\
    [list ${::IMEX::libVar}/mmmc/AR_register_m.sdc]
create_analysis_view -name worst_analysis -constraint_mode constraint -delay_corner wrost_corner
set_analysis_view -setup [list worst_analysis] -hold [list worst_analysis]
